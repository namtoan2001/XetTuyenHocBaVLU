import { WebComponentWrapper, WebComponentWrapperOptions, startsWith, endsWith } from '@angular-architects/module-federation-tools';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{
  path: '',
  redirectTo: 'r-info',
  pathMatch: 'full'
},{
  matcher: startsWith('a-auth'),
  component: WebComponentWrapper,
  data: {
    type: 'module',
    remoteEntry: 'http://localhost:4301/remoteEntry.js',
    exposedModule: './web-components',
    elementName: 'a-auth'
  } as WebComponentWrapperOptions
  },
  {
    path: 'r-info',
    component: WebComponentWrapper,
    data: {
      type: 'script',
      remoteEntry: 'http://localhost:4302/remoteEntry.js',
      remoteName: 'r_info',
      elementName: 'r-info',
      exposedModule: './web-components'
    } as WebComponentWrapperOptions
    }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
