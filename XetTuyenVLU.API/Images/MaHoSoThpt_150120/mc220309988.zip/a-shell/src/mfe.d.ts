declare module 'a-auth/web-components';
