import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email = '';
  password = '';
  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
  }

  onInputEmail($event: any) {
    this.email = $event.target.value;
  }

  onInputPassword($event: any) {
    this.password = $event.target.value;
  }

  login($event: any) {
    $event.preventDefault();
    if(!this.email || !this.password) {
      alert('Thông tin đăng nhập không được để trống');
      return;
    }

    if(this.email === 'lvp' && this.password === 'lvp') {
      localStorage.setItem('token', 'xiiskjkjkooiwoieowioeiwo8800sdsd');
      alert('Đăng nhập thành công');
      const loggedEvent = new CustomEvent('logged');
      window.dispatchEvent(loggedEvent);
    } else {
      alert('Thông tin đăng nhập không chính xác')
    }
  }
}
