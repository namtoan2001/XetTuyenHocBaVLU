import React, { useEffect, useState } from 'react';
import './App.css';
import './index.css';

function App() {
  const [isLogged, setIsLogged] = useState(false);
  useEffect(() => {
    const token = localStorage.getItem('token');
    // Giả lập call api check token tại BE server tại đây, nếu token hợp lệ thì thực hiện set State logged. Nếu token không validate được thì sẽ route về màn home
    if(token === 'xiiskjkjkooiwoieowioeiwo8800sdsd') {
      setIsLogged(true);
    }
  }, []);
  const onLogoutClick = () => {
    localStorage.clear();
  }

  const onGoToAuthClick =() => {
    const authEvent = new CustomEvent('auth');
    window.dispatchEvent(authEvent);
  }
  return (
    <div className="w-screen h-screen overflow-auto">
     <div className="w-full bg-blue-700 text-white h-[60px] shadow-blue-500/50 flex justify-end px-5">
     { isLogged ? <button onClick={onLogoutClick}>Đăng xuất</button>:<button onClick={onGoToAuthClick}>Đăng nhập/Đăng ký</button>}
      </div>
      <iframe className="w-full h-[calc(100%-60px)]" src="https://lienviettech.com.vn/gioi-thieu" title="LVT"></iframe>
    </div>
  );
}

export default App;