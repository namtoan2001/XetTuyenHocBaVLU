import React from "react";
import ReactDOM from 'react-dom'
import App from './App';

class RInfoElement extends HTMLElement {
    connectedCallback() {
        console.log('connected');
        ReactDOM.render(<App/>, this);
    }
}

customElements.define('r-info', RInfoElement);